#!/system/bin/sh
# Auto-apply Pixel 5 fingerprint and MagiskHide settings for CUE
/sbin/magisk resetprop ro.build.fingerprint "google/redfin/redfin:11/RQ3A.211001.001/7641976:user/release-keys"
/sbin/magisk resetprop ro.bootimage.build.fingerprint "google/redfin/redfin:11/RQ3A.211001.001/7641976:user/release-keys"
/sbin/magisk resetprop ro.build.type "user"
/sbin/magisk resetprop ro.build.tags "release-keys"
/sbin/magisk resetprop ro.debuggable 0
/sbin/magisk resetprop ro.product.model "Pixel 5"
/sbin/magisk resetprop ro.product.brand "google"
/sbin/magisk resetprop ro.product.name "redfin"
/sbin/magisk resetprop ro.product.device "redfin"
/sbin/magisk resetprop ro.product.manufacturer "Google"
/sbin/magisk magiskhide enable
/sbin/magisk magiskhide add ai.manus.agents
/sbin/magisk magiskhide add com.google.android.gms
/sbin/magisk magiskhide add com.android.vending
