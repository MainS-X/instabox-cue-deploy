#!/bin/bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "=== 1. Checking Redroid Container ==="
CURRENT_IMG=$(docker inspect instabox-android --format '{{.Config.Image}}' 2>/dev/null || echo "")

TARGET_IMG="erstt/redroid@sha256:ba5a5a449d11e0b15ced984b55237e13bd056cbcbc9471f5fd6a63adb32f7f9e"
if [ "$CURRENT_IMG" != "$TARGET_IMG" ]; then
    echo "Starting customized Redroid 11 container ($TARGET_IMG)..."
    docker stop instabox-android 2>/dev/null || true
    docker rm instabox-android 2>/dev/null || true
    docker run -d --name instabox-android --privileged       -v instabox-android-data:/data       -p 127.0.0.1:5555:5555       $TARGET_IMG       androidboot.redroid_gpu_mode=guest qemu=1 androidboot.hardware=redroid
fi

echo "=== 2. Waiting for Android to boot ==="
adb connect 127.0.0.1:5555 >/dev/null 2>&1 || true
adb -s 127.0.0.1:5555 wait-for-device
while [ "$(adb -s 127.0.0.1:5555 shell getprop sys.boot_completed 2>/dev/null | tr -d '')" != "1" ]; do
    sleep 2
done
echo "Android booted successfully!"

echo "=== 3. Configuring Magisk & Pixel 5 Device Spoof ==="
docker exec instabox-android mkdir -p /data/adb/service.d
docker exec -i instabox-android sh -c 'cat > /data/adb/service.d/cue-fix.sh' < "$DIR/cue-fix.sh"
docker exec instabox-android chmod +x /data/adb/service.d/cue-fix.sh
docker exec instabox-android sh /data/adb/service.d/cue-fix.sh

echo "=== 4. Installing Patched CUE APKs ==="
adb -s 127.0.0.1:5555 install-multiple -r -i com.android.vending   "$DIR/base.apk"   "$DIR/split_config.arm64_v8a.apk"   "$DIR/split_config.mdpi.apk"

echo "=== 5. Installing and Configuring ADB Keyboard ==="
adb -s 127.0.0.1:5555 install -r "$DIR/adbkeyboard.apk"
adb -s 127.0.0.1:5555 shell ime enable com.android.adbkeyboard/.AdbIME
adb -s 127.0.0.1:5555 shell ime set com.android.adbkeyboard/.AdbIME

echo "=== 6. Launching CUE ==="
adb -s 127.0.0.1:5555 shell am start -n ai.manus.agents/.launcher.CueBlueGear

echo "======================================================"
echo "🎉 CUE deployment completed successfully!"
echo "Open the InstaBox Desktop / Computer tab to log in."
echo "======================================================"
